var countre = 1;
function add_more_field() {
    countre += 1
    html = '<div class="grid-form">\
        <div class="full-width" id="row'+ countre + '">\
            <h2 class="bold">Question<span>*</span></h2>\
            <input type="text" class="question" required>\
        </div >\
        <div class="full-width">\
            <h2 class="bold">Question<span>*</span></h2>\
            <input type="text" name="question'+countre+'" class="question" required>\
        </div>\
        <div class="Options">\
            <div class="width_fifty">\
                <h2 class="bold">Option1<span>*</span></h2>\
                <input type="text" name="Option'+countre+'" class="Option1" required>\
                <div class="toggle"></div>\
            </div>\
            <div class="width_fifty">\
                <h2 class="bold">Option2<span>*</span></h2>\
                <input type="text" name="Option'+countre+'" class="Option2" required>\
                <div class="toggle"></div>\
            </div>\
            <div class="width_fifty">\
                <h2 class="bold">Option3<span>*</span></h2>\
                <input type="text" name="Option'+countre+'" class="Option3" required>\
                <div class="toggle"></div>
            </div>\
            <div class="width_fifty">\
                <h2 class="bold">Option4<span>*</span></h2>\
                <input type="text" name="Option'+countre+'" class="Option4" required>\
                <div class="toggle"></div>\
            </div>\

        </div>\
    </div>'
    var form = document.getElementById('question-add')
    form.innerHTML+=html
}