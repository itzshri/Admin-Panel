// var countre = 1;
// function add_more_field() {
//     countre += 1
//     html = '<div class="grid-form">\
//         <div class="full-width" id="row'+ countre + '">\
//             <h2 class="bold">Question<span>*</span></h2>\
//             <input type="text" class="question" required>\
//         </div >\
//         <div class="full-width">\
//             <h2 class="bold">Question<span>*</span></h2>\
//             <input type="text" name="question'+countre+'" class="question" required>\
//         </div>\
//         <div class="Options">\
//             <div class="width_fifty">\
//                 <h2 class="bold">Option1<span>*</span></h2>\
//                 <input type="text" name="Option'+countre+'" class="Option1" required>\
//                 <div class="toggle"></div>\
//             </div>\
//             <div class="width_fifty">\
//                 <h2 class="bold">Option2<span>*</span></h2>\
//                 <input type="text" name="Option'+countre+'" class="Option2" required>\
//                 <div class="toggle"></div>\
//             </div>\
//             <div class="width_fifty">\
//                 <h2 class="bold">Option3<span>*</span></h2>\
//                 <input type="text" name="Option'+countre+'" class="Option3" required>\
//                 <div class="toggle"></div>
//             </div>\
//             <div class="width_fifty">\
//                 <h2 class="bold">Option4<span>*</span></h2>\
//                 <input type="text" name="Option'+countre+'" class="Option4" required>\
//                 <div class="toggle"></div>\
//             </div>\

//         </div>\
//     </div>'
//     var form = document.getElementById('question-add')
//     form.innerHTML+=html
// }

const body = document.querySelector("body"),
  modeToggle = body.querySelector(".mode-toggle");
sidebar = body.querySelector("nav");
sidebarToggle = body.querySelector(".sidebar-toggle");

let getMode = localStorage.getItem("mode");
if (getMode && getMode === "dark") {
  body.classList.toggle("dark");
}

let getStatus = localStorage.getItem("status");
if (getStatus && getStatus === "close") {
  sidebar.classList.toggle("close");
}

modeToggle.addEventListener("click", () => {
  body.classList.toggle("dark");
  if (body.classList.contains("dark")) {
    localStorage.setItem("mode", "dark");
  } else {
    localStorage.setItem("mode", "light");
  }
});

sidebarToggle.addEventListener("click", () => {
  sidebar.classList.toggle("close");
  if (sidebar.classList.contains("close")) {
    localStorage.setItem("status", "close");
  } else {
    localStorage.setItem("status", "open");
  }
});

// Function to show the selected table and hide the others
function showTable(tableId) {
  const tables = document.getElementsByClassName("activity");
  for (let i = 0; i < tables.length; i++) {
    if (tables[i].id === tableId) {
      tables[i].style.display = "block";
    } else {
      tables[i].style.display = "none";
    }
  }
}
